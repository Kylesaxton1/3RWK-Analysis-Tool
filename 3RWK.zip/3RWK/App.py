import tkinter as tk, json
from pprint import pprint
'''
import requests as rq, json as js, pandas as pd

currentURL = "https://ofmpub.epa.gov/frs_public2/frs_rest_services.get_facilities?state_abbr=PA&city_name=Pittsburgh&city_name=Pittsburgh,%20City%20of&pgm_sys_acrnm=NPDES&city_name=Pittsburgh,%20PA&county_name=Allegheny&county_name=Allegheny%20County&program_output=yes&output=JSON"
response = rq.get(currentURL)
data = response.json()

results = data['Results']
results = results['FRSFacility']
fDF = pd.DataFrame(results)

npdes = {}
for index, row in fDF.iterrows():
    prm = row['ProgramFacilities']
    for prm_dict in prm:
        if prm_dict['ProgramSystemAccronym'] == "NPDES":
            npdes = prm_dict
            row["ProgramFacilities"] = npdes

npdes_info = fDF["ProgramFacilities"]
fDF = fDF.drop("ProgramFacilities", axis='columns')

i = 0; pac = {}; pid = {}; pFac = {}
for npdes_dict in npdes_info:
    pac[i] = npdes_dict["ProgramSystemAcronym"]
    pid[i] = npdes_dict["ProgramSystemId"]
    pFac[i] = npdes_dict["ProgramFacilityName"]
    i += 1

fDF['ProgramSystemAcronym'] = fDF.index.map(pac) 
fDF['PID'] = fDF.index.map(pid) 
fDF['ProgramFacilityName'] = fDF.index.map(pFac) 

# print(facility_df.head())

# save the cleaned dataframe to a JSON file
fDF.to_json(".data/facilities.json")
'''

#Filter for finding facilities that match search
def flt(ind:str) -> bool:
    ind, item = ind
    return val.upper() in dt[ind][1][1].upper()

#Event Handler for search button/enter
def EnterClick(Event):
    global val
    
    #retrieve search value
    strs: list[str] = []
    for entry in entries:
        strs.append(entry.get()); entry.delete(0, tk.END)

    #make global variable for search valie
    val = strs[0]

    #make new window and frame
    window2: tk.Tk = tk.Tk()
    frame2 = tk.Frame(master = window2, width = 115)
    frame2.pack()

    #get filtered data
    filt = filter(flt, dt.items())
    
    #Produce string to display
    finalStr = ''
    for facility in filt:
        for lst in facility:
            if str == type(lst):
                continue
            for tup in lst:
                if tup[1] == None:
                    finalStr += "NONE\t"
                else:
                    finalStr += tup[1][:6] + '\t'
            finalStr += '\n'
    #print(finalStr)
   
    #Make filtered data visible        
    text = tk.Text(frame2, height = 300, width=115)
    text.insert(tk.END, "RegId\tFacNm\tLocAd\tSuppL\tCityN\tCounty\tStAbr\tZipCode\tFIPSC\tLat83\tLon83\tPSA\ttPID\tPFN\n")
    text.insert(tk.END, finalStr)
    text.pack()

#Put all features on page
def toutpacker(): 
    for label in labels:
        label.pack()

    for entry in entries:
        entry.pack()

    for button in buttons:
        button.pack()

#Main Entry point
def main():
    global labels, entries, buttons, dt, val, window, frame
    labels = []
    entries = []
    buttons= []
    dt = {}


    val = ''

    with open('data/facilities.json') as data:
        d:dict[str, dict[str, str]] = json.load(data)
        for i in d:
            #print(i)
            for j in d[i]:
                try:
                    dt.get(j).append((i, d[i][j]))
                except:
                    dt.update({j:[(i, d[i][j])]})

    window = tk.Tk(); frame = tk.Frame(master=window, width=200, height=300)
    frame.pack()
    window.bind("<Key-Return>",EnterClick)

    labels.append(tk.Label(master=frame, text = "Three Rivers Water Keeping"))
    labels.append(tk.Label(master=frame, text = "Facility Name"))

    entries.append(tk.Entry(master=frame, text = "Facility Name"))

    buttons.append(tk.Button(master=frame, text = "Enter"))
    buttons[0].bind("<Button-1>", EnterClick)
    toutpacker()
    window.mainloop()

if __name__ == "__main__":
    main()
